Problem 1:
Files Used: MergeSortGenerics.java, MergeSort.java, Shuffle.java, Timer.java
MergeSortGenerics.java - Implemented Merge Sort and Insertion Sort with Generics
MergeSort.java - Implemented Merge Sort with int[] 
Shuffle.java, Timer.java - Helper files


Problem 2:
Files Used: Diameter.java, Graph.java, ArrayIterator.java
Diameter.java - Program that calculates the Diamater of a tree
Graph.java ArrayIterator.java - Helper files
We have tested the program with the following inputs.

Input - 1
--------------------------------------------
10 9
1 2 1
2 7 1
7 9 1
7 8 1
2 3 1
3 4 1
3 10 1
3 5 1
5 6 1

Output
-----------------
Length of diameter: 5
Path of diameter: 6 5 3 2 7 8

Input - 2
----------------------------------------------

5 4
1 2 1
1 3 1
2 4 1
3 5 1

Output
-----------------
Length of diameter: 4
Path of diameter: 5 3 1 2 4

Input -3
----------------------------------------------

16 15
1 2 1
1 3 1
1 4 1
2 5 1
2 6 1
4 7 1
4 8 1
4 9 1
5 10 1
5 11 1
7 12 1
7 13 1
11 14 1
11 15 1
11 16 1

Output
------------------
Length of diameter: 7
Path of diameter: 13 7 4 1 2 5 11 16